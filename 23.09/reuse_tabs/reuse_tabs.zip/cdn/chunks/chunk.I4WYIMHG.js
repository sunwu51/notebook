import {
  SlFormatNumber
} from "./chunk.5ODI3JJ2.js";

// src/components/format-number/format-number.ts
var format_number_default = SlFormatNumber;
SlFormatNumber.define("sl-format-number");

export {
  format_number_default
};
