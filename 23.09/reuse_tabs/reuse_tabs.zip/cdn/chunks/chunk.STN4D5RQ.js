import {
  SlCopyButton
} from "./chunk.7KCYHPAQ.js";

// src/components/copy-button/copy-button.ts
var copy_button_default = SlCopyButton;
SlCopyButton.define("sl-copy-button");

export {
  copy_button_default
};
