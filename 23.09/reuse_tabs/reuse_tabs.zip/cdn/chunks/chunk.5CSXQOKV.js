import {
  SlRating
} from "./chunk.3SNIH4MP.js";

// src/components/rating/rating.ts
var rating_default = SlRating;
SlRating.define("sl-rating");

export {
  rating_default
};
