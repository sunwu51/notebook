import {
  SlDivider
} from "./chunk.U2D46ZMA.js";

// src/components/divider/divider.ts
var divider_default = SlDivider;
SlDivider.define("sl-divider");

export {
  divider_default
};
