import {
  SlMenuLabel
} from "./chunk.Y7TREFFK.js";

// src/components/menu-label/menu-label.ts
var menu_label_default = SlMenuLabel;
SlMenuLabel.define("sl-menu-label");

export {
  menu_label_default
};
