import {
  SlSwitch
} from "./chunk.IWITRU34.js";

// src/components/switch/switch.ts
var switch_default = SlSwitch;
SlSwitch.define("sl-switch");

export {
  switch_default
};
