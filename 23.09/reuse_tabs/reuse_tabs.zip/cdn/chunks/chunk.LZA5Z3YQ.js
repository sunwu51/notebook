import {
  LocalizeController
} from "./chunk.UP2KMO5A.js";

// src/utilities/localize.ts
var LocalizeController2 = class extends LocalizeController {
};

export {
  LocalizeController2 as LocalizeController
};
