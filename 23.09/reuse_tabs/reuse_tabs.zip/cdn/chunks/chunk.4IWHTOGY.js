import {
  Z
} from "./chunk.CYORH2MW.js";

// node_modules/lit-html/directive-helpers.js
var { I: l } = Z;
var n = (o, l2) => void 0 === l2 ? void 0 !== (null == o ? void 0 : o._$litType$) : (null == o ? void 0 : o._$litType$) === l2;
var e = (o) => void 0 === o.strings;
var f = {};
var s = (o, l2 = f) => o._$AH = l2;

export {
  n,
  e,
  s
};
/*! Bundled license information:

lit-html/directive-helpers.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
