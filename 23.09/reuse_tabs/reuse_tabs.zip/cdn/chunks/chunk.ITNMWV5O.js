import {
  component_styles_default
} from "./chunk.FQG5QBCI.js";
import {
  i
} from "./chunk.CYORH2MW.js";

// src/components/resize-observer/resize-observer.styles.ts
var resize_observer_styles_default = i`
  ${component_styles_default}

  :host {
    display: contents;
  }
`;

export {
  resize_observer_styles_default
};
