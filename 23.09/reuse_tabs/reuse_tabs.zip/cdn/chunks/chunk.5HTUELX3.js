import {
  SlProgressRing
} from "./chunk.U57C32JB.js";

// src/components/progress-ring/progress-ring.ts
var progress_ring_default = SlProgressRing;
SlProgressRing.define("sl-progress-ring");

export {
  progress_ring_default
};
