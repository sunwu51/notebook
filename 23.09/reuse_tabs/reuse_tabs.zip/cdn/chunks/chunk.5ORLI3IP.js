import {
  SlDrawer
} from "./chunk.LLHARA6N.js";

// src/components/drawer/drawer.ts
var drawer_default = SlDrawer;
SlDrawer.define("sl-drawer");

export {
  drawer_default
};
