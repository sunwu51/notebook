import {
  SlButton
} from "./chunk.SIRID5O6.js";

// src/components/button/button.ts
var button_default = SlButton;
SlButton.define("sl-button");

export {
  button_default
};
