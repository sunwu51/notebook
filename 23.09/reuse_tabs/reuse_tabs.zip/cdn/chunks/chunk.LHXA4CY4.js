import {
  SlMutationObserver
} from "./chunk.TVIKNRDE.js";

// src/components/mutation-observer/mutation-observer.ts
var mutation_observer_default = SlMutationObserver;
SlMutationObserver.define("sl-mutation-observer");

export {
  mutation_observer_default
};
