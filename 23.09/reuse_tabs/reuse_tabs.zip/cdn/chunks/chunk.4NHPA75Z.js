import {
  SlIcon
} from "./chunk.HAUXDFZJ.js";

// src/components/icon/icon.ts
var icon_default = SlIcon;
SlIcon.define("sl-icon");

export {
  icon_default
};
