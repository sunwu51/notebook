import {
  SlRadioGroup
} from "./chunk.3GMETAQA.js";

// src/components/radio-group/radio-group.ts
var radio_group_default = SlRadioGroup;
SlRadioGroup.define("sl-radio-group");

export {
  radio_group_default
};
