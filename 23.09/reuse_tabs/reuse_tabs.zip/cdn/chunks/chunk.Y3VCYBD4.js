import {
  SlMenu
} from "./chunk.345GMLJC.js";

// src/components/menu/menu.ts
var menu_default = SlMenu;
SlMenu.define("sl-menu");

export {
  menu_default
};
