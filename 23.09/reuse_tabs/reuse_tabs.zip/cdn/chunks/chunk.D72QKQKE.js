import {
  SlDetails
} from "./chunk.WB6PZ3X4.js";

// src/components/details/details.ts
var details_default = SlDetails;
SlDetails.define("sl-details");

export {
  details_default
};
