import {
  SlTab
} from "./chunk.N2KN3ITW.js";

// src/components/tab/tab.ts
var tab_default = SlTab;
SlTab.define("sl-tab");

export {
  tab_default
};
