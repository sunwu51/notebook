import {
  SlCarouselItem
} from "./chunk.NFP5WPQO.js";

// src/components/carousel-item/carousel-item.ts
var carousel_item_default = SlCarouselItem;
SlCarouselItem.define("sl-carousel-item");

export {
  carousel_item_default
};
