import {
  SlDialog
} from "./chunk.SIUQ4VWC.js";

// src/components/dialog/dialog.ts
var dialog_default = SlDialog;
SlDialog.define("sl-dialog");

export {
  dialog_default
};
