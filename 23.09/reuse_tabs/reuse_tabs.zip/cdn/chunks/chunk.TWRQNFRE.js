import {
  SlOption
} from "./chunk.527PKT63.js";

// src/components/option/option.ts
var option_default = SlOption;
SlOption.define("sl-option");

export {
  option_default
};
