import {
  SlTree
} from "./chunk.JZJ4JVL5.js";

// src/components/tree/tree.ts
var tree_default = SlTree;
SlTree.define("sl-tree");

export {
  tree_default
};
