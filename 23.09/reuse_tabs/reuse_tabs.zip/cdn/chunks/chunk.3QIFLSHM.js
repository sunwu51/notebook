import {
  SlInclude
} from "./chunk.IYPGOOEF.js";

// src/components/include/include.ts
var include_default = SlInclude;
SlInclude.define("sl-include");

export {
  include_default
};
