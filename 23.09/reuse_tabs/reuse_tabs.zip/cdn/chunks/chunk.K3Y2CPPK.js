import {
  SlTag
} from "./chunk.5OHOXFON.js";

// src/components/tag/tag.ts
var tag_default = SlTag;
SlTag.define("sl-tag");

export {
  tag_default
};
