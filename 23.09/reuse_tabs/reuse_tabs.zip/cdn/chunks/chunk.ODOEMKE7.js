import {
  SlResizeObserver
} from "./chunk.KRQIAZSR.js";

// src/components/resize-observer/resize-observer.ts
var resize_observer_default = SlResizeObserver;
SlResizeObserver.define("sl-resize-observer");

export {
  resize_observer_default
};
