import {
  component_styles_default
} from "./chunk.FQG5QBCI.js";
import {
  i
} from "./chunk.CYORH2MW.js";

// src/components/include/include.styles.ts
var include_styles_default = i`
  ${component_styles_default}

  :host {
    display: block;
  }
`;

export {
  include_styles_default
};
