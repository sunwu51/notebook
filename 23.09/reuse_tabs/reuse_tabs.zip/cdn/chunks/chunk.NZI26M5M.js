import {
  SlAnimation
} from "./chunk.GHSUO25V.js";

// src/components/animation/animation.ts
var animation_default = SlAnimation;
SlAnimation.define("sl-animation");

export {
  animation_default
};
