import {
  SlFormatBytes
} from "./chunk.ABXSFS6K.js";

// src/components/format-bytes/format-bytes.ts
var format_bytes_default = SlFormatBytes;
SlFormatBytes.define("sl-format-bytes");

export {
  format_bytes_default
};
