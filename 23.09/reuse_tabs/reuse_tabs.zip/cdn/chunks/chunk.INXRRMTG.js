import {
  SlVisuallyHidden
} from "./chunk.DLZGXMOX.js";

// src/components/visually-hidden/visually-hidden.ts
var visually_hidden_default = SlVisuallyHidden;
SlVisuallyHidden.define("sl-visually-hidden");

export {
  visually_hidden_default
};
