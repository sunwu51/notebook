import {
  component_styles_default
} from "./chunk.FQG5QBCI.js";
import {
  i
} from "./chunk.CYORH2MW.js";

// src/components/animation/animation.styles.ts
var animation_styles_default = i`
  ${component_styles_default}

  :host {
    display: contents;
  }
`;

export {
  animation_styles_default
};
