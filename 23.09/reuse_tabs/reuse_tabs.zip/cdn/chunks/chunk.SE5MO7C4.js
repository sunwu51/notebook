import {
  SlSkeleton
} from "./chunk.W5NS462A.js";

// src/components/skeleton/skeleton.ts
var skeleton_default = SlSkeleton;
SlSkeleton.define("sl-skeleton");

export {
  skeleton_default
};
