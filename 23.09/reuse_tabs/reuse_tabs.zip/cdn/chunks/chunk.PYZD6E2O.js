import {
  SlInput
} from "./chunk.PG2YQQKG.js";

// src/components/input/input.ts
var input_default = SlInput;
SlInput.define("sl-input");

export {
  input_default
};
