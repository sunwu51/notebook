import {
  A
} from "./chunk.CYORH2MW.js";

// node_modules/lit-html/directives/if-defined.js
var l = (l2) => null != l2 ? l2 : A;

export {
  l
};
/*! Bundled license information:

lit-html/directives/if-defined.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
