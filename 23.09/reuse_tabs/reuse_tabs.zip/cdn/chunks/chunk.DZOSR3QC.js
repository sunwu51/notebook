import {
  SlBadge
} from "./chunk.3R4LTGQO.js";

// src/components/badge/badge.ts
var badge_default = SlBadge;
SlBadge.define("sl-badge");

export {
  badge_default
};
