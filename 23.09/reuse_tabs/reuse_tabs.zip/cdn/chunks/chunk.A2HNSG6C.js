import {
  SlTreeItem
} from "./chunk.6U7YXO2I.js";

// src/components/tree-item/tree-item.ts
var tree_item_default = SlTreeItem;
SlTreeItem.define("sl-tree-item");

export {
  tree_item_default
};
