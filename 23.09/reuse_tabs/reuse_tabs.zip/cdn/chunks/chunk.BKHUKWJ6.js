import {
  SlRelativeTime
} from "./chunk.NJJA5ODV.js";

// src/components/relative-time/relative-time.ts
var relative_time_default = SlRelativeTime;
SlRelativeTime.define("sl-relative-time");

export {
  relative_time_default
};
