import {
  SlSplitPanel
} from "./chunk.G74GH4Z7.js";

// src/components/split-panel/split-panel.ts
var split_panel_default = SlSplitPanel;
SlSplitPanel.define("sl-split-panel");

export {
  split_panel_default
};
