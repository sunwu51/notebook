import {
  SlSpinner
} from "./chunk.YRXRCFKA.js";

// src/components/spinner/spinner.ts
var spinner_default = SlSpinner;
SlSpinner.define("sl-spinner");

export {
  spinner_default
};
