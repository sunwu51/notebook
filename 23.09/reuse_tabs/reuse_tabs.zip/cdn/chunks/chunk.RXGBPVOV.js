import {
  SlCarousel
} from "./chunk.GKH4LBJE.js";

// src/components/carousel/carousel.ts
var carousel_default = SlCarousel;
SlCarousel.define("sl-carousel");

export {
  carousel_default
};
