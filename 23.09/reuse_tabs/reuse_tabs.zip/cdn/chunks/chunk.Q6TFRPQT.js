import {
  component_styles_default
} from "./chunk.FQG5QBCI.js";
import {
  i
} from "./chunk.CYORH2MW.js";

// src/components/mutation-observer/mutation-observer.styles.ts
var mutation_observer_styles_default = i`
  ${component_styles_default}

  :host {
    display: contents;
  }
`;

export {
  mutation_observer_styles_default
};
