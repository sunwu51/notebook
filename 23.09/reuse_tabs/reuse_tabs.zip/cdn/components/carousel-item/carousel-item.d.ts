import SlCarouselItem from './carousel-item.component.js';
export * from './carousel-item.component.js';
export default SlCarouselItem;
declare global {
    interface HTMLElementTagNameMap {
        'sl-carousel-item': SlCarouselItem;
    }
}
