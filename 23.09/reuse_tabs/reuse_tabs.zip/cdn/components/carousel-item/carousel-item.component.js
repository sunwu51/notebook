import {
  SlCarouselItem
} from "../../chunks/chunk.NFP5WPQO.js";
import "../../chunks/chunk.6TJJYPNU.js";
import "../../chunks/chunk.OEOITZKB.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  SlCarouselItem as default
};
