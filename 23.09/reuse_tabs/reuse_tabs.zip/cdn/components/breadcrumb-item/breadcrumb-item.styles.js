import {
  breadcrumb_item_styles_default
} from "../../chunks/chunk.M4T5SJDM.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  breadcrumb_item_styles_default as default
};
