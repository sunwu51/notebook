import SlBreadcrumbItem from './breadcrumb-item.component.js';
export * from './breadcrumb-item.component.js';
export default SlBreadcrumbItem;
declare global {
    interface HTMLElementTagNameMap {
        'sl-breadcrumb-item': SlBreadcrumbItem;
    }
}
