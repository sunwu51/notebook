import SlFormatDate from './format-date.component.js';
export * from './format-date.component.js';
export default SlFormatDate;
declare global {
    interface HTMLElementTagNameMap {
        'sl-format-date': SlFormatDate;
    }
}
