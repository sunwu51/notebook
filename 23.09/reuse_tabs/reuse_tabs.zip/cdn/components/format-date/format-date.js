import {
  format_date_default
} from "../../chunks/chunk.4JTT5X2V.js";
import "../../chunks/chunk.PS4KRVWV.js";
import "../../chunks/chunk.LZA5Z3YQ.js";
import "../../chunks/chunk.UP2KMO5A.js";
import "../../chunks/chunk.OEOITZKB.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  format_date_default as default
};
