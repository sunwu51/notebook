import SlButton from './button.component.js';
export * from './button.component.js';
export default SlButton;
declare global {
    interface HTMLElementTagNameMap {
        'sl-button': SlButton;
    }
}
