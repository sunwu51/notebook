import SlIcon from './icon.component.js';
export * from './icon.component.js';
export default SlIcon;
declare global {
    interface HTMLElementTagNameMap {
        'sl-icon': SlIcon;
    }
}
