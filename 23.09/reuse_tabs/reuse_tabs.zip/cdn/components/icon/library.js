import {
  getIconLibrary,
  registerIconLibrary,
  unregisterIconLibrary,
  unwatchIcon,
  watchIcon
} from "../../chunks/chunk.3WAW4E2K.js";
import "../../chunks/chunk.P7ZG6EMR.js";
import "../../chunks/chunk.VRTJZYIC.js";
import "../../chunks/chunk.3Y6SB6QS.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  getIconLibrary,
  registerIconLibrary,
  unregisterIconLibrary,
  unwatchIcon,
  watchIcon
};
