import type { IconLibrary } from './library.js';
declare const library: IconLibrary;
export default library;
