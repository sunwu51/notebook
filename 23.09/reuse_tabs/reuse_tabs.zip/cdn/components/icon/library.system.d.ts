import type { IconLibrary } from './library.js';
declare const systemLibrary: IconLibrary;
export default systemLibrary;
