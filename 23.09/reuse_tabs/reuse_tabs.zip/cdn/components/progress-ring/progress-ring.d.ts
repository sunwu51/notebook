import SlProgressRing from './progress-ring.component.js';
export * from './progress-ring.component.js';
export default SlProgressRing;
declare global {
    interface HTMLElementTagNameMap {
        'sl-progress-ring': SlProgressRing;
    }
}
