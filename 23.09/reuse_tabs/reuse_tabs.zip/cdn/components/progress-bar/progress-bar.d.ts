import SlProgressBar from './progress-bar.component.js';
export * from './progress-bar.component.js';
export default SlProgressBar;
declare global {
    interface HTMLElementTagNameMap {
        'sl-progress-bar': SlProgressBar;
    }
}
