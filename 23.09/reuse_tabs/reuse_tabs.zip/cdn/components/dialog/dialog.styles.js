import {
  dialog_styles_default
} from "../../chunks/chunk.MQMD74KM.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  dialog_styles_default as default
};
