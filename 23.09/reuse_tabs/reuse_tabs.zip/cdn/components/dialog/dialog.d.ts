import SlDialog from './dialog.component.js';
export * from './dialog.component.js';
export default SlDialog;
declare global {
    interface HTMLElementTagNameMap {
        'sl-dialog': SlDialog;
    }
}
