import {
  menu_item_styles_default
} from "../../chunks/chunk.MKFCW46J.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  menu_item_styles_default as default
};
