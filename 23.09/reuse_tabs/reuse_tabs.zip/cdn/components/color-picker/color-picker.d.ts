import SlColorPicker from './color-picker.component.js';
export * from './color-picker.component.js';
export default SlColorPicker;
declare global {
    interface HTMLElementTagNameMap {
        'sl-color-picker': SlColorPicker;
    }
}
