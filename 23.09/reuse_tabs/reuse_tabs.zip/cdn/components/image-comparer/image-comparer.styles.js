import {
  image_comparer_styles_default
} from "../../chunks/chunk.HNY7YLPC.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  image_comparer_styles_default as default
};
