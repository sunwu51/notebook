import SlImageComparer from './image-comparer.component.js';
export * from './image-comparer.component.js';
export default SlImageComparer;
declare global {
    interface HTMLElementTagNameMap {
        'sl-image-comparer': SlImageComparer;
    }
}
