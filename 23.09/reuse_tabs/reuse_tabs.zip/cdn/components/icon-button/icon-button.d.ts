import SlIconButton from './icon-button.component.js';
export * from './icon-button.component.js';
export default SlIconButton;
declare global {
    interface HTMLElementTagNameMap {
        'sl-icon-button': SlIconButton;
    }
}
