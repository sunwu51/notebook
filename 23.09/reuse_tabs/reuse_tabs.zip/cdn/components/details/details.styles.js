import {
  details_styles_default
} from "../../chunks/chunk.67HE6XBT.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  details_styles_default as default
};
