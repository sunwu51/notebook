import SlDetails from './details.component.js';
export * from './details.component.js';
export default SlDetails;
declare global {
    interface HTMLElementTagNameMap {
        'sl-details': SlDetails;
    }
}
