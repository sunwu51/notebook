import {
  SlMutationObserver
} from "../../chunks/chunk.TVIKNRDE.js";
import "../../chunks/chunk.Q6TFRPQT.js";
import "../../chunks/chunk.VQ3XOPCT.js";
import "../../chunks/chunk.OEOITZKB.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  SlMutationObserver as default
};
