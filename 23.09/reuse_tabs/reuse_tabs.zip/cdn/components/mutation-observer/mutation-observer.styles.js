import {
  mutation_observer_styles_default
} from "../../chunks/chunk.Q6TFRPQT.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  mutation_observer_styles_default as default
};
