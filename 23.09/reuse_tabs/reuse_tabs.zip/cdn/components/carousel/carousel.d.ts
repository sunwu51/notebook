import SlCarousel from './carousel.component.js';
export * from './carousel.component.js';
export default SlCarousel;
declare global {
    interface HTMLElementTagNameMap {
        'sl-carousel': SlCarousel;
    }
}
