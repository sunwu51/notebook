import SlButtonGroup from './button-group.component.js';
export * from './button-group.component.js';
export default SlButtonGroup;
declare global {
    interface HTMLElementTagNameMap {
        'sl-button-group': SlButtonGroup;
    }
}
