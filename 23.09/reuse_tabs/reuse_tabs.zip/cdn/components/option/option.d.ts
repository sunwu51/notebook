import SlOption from './option.component.js';
export * from './option.component.js';
export default SlOption;
declare global {
    interface HTMLElementTagNameMap {
        'sl-option': SlOption;
    }
}
