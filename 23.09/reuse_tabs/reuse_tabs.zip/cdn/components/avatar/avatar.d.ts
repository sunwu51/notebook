import SlAvatar from './avatar.component.js';
export * from './avatar.component.js';
export default SlAvatar;
declare global {
    interface HTMLElementTagNameMap {
        'sl-avatar': SlAvatar;
    }
}
