import {
  SlMenuLabel
} from "../../chunks/chunk.Y7TREFFK.js";
import "../../chunks/chunk.V7G2BEYY.js";
import "../../chunks/chunk.OEOITZKB.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  SlMenuLabel as default
};
