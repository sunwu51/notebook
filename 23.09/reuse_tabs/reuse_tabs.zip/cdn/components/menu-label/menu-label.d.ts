import SlMenuLabel from './menu-label.component.js';
export * from './menu-label.component.js';
export default SlMenuLabel;
declare global {
    interface HTMLElementTagNameMap {
        'sl-menu-label': SlMenuLabel;
    }
}
