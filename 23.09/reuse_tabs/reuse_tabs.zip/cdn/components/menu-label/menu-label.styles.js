import {
  menu_label_styles_default
} from "../../chunks/chunk.V7G2BEYY.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  menu_label_styles_default as default
};
