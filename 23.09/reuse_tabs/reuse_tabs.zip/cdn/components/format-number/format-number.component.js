import {
  SlFormatNumber
} from "../../chunks/chunk.5ODI3JJ2.js";
import "../../chunks/chunk.LZA5Z3YQ.js";
import "../../chunks/chunk.UP2KMO5A.js";
import "../../chunks/chunk.OEOITZKB.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  SlFormatNumber as default
};
