import {
  input_styles_default
} from "../../chunks/chunk.ZJUZODNS.js";
import "../../chunks/chunk.G75TI7GH.js";
import "../../chunks/chunk.FQG5QBCI.js";
import "../../chunks/chunk.CYORH2MW.js";
import "../../chunks/chunk.LKA3TPUC.js";
export {
  input_styles_default as default
};
