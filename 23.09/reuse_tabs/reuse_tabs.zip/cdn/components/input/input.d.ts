import SlInput from './input.component.js';
export * from './input.component.js';
export default SlInput;
declare global {
    interface HTMLElementTagNameMap {
        'sl-input': SlInput;
    }
}
