import SlCopyButton from './copy-button.component.js';
export * from './copy-button.component.js';
export default SlCopyButton;
declare global {
    interface HTMLElementTagNameMap {
        'sl-copy-button': SlCopyButton;
    }
}
