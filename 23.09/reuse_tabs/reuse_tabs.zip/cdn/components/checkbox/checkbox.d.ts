import SlCheckbox from './checkbox.component.js';
export * from './checkbox.component.js';
export default SlCheckbox;
declare global {
    interface HTMLElementTagNameMap {
        'sl-checkbox': SlCheckbox;
    }
}
