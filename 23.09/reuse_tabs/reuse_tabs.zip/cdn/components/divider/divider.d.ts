import SlDivider from './divider.component.js';
export * from './divider.component.js';
export default SlDivider;
declare global {
    interface HTMLElementTagNameMap {
        'sl-divider': SlDivider;
    }
}
