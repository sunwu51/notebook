import SlInclude from './include.component.js';
export * from './include.component.js';
export default SlInclude;
declare global {
    interface HTMLElementTagNameMap {
        'sl-include': SlInclude;
    }
}
