import SlAnimatedImage from './animated-image.component.js';
export * from './animated-image.component.js';
export default SlAnimatedImage;
declare global {
    interface HTMLElementTagNameMap {
        'sl-animated-image': SlAnimatedImage;
    }
}
