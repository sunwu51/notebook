import SlBadge from './badge.component.js';
export * from './badge.component.js';
export default SlBadge;
declare global {
    interface HTMLElementTagNameMap {
        'sl-badge': SlBadge;
    }
}
