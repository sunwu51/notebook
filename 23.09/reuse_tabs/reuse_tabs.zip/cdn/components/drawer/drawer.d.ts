import SlDrawer from './drawer.component.js';
export * from './drawer.component.js';
export default SlDrawer;
declare global {
    interface HTMLElementTagNameMap {
        'sl-drawer': SlDrawer;
    }
}
