import SlQrCode from './qr-code.component.js';
export * from './qr-code.component.js';
export default SlQrCode;
declare global {
    interface HTMLElementTagNameMap {
        'sl-qr-code': SlQrCode;
    }
}
